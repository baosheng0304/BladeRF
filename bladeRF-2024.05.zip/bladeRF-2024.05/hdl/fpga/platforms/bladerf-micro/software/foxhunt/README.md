Fox Hunt Demo Application
=========================

This application implements a simple, standalone OOK transmitter.

TODO:
- Implement tone generator HDL
- Control it from the Nios
- Pipe it into the TX sample flow
