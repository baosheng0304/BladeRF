# Python3 TX/RX Example #

This example illustrates how to transmit and receive using the bladeRF Python3
bindings. The example can perform these operations in either full or half
duplex and is configurable with the provided ConfigParser INI file.

In order for this to work, libbladeRF and the
[bladeRF Python3 bindings](../../../libraries/libbladeRF_bindings/python)
must be installed on the host sytem.
