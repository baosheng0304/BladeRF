var searchData=
[
  ['usb_5faddr_694',['usb_addr',['../structbladerf__devinfo.html#a1316ffb2f3147a76bbdf84fa2db3e490',1,'bladerf_devinfo']]],
  ['usb_5fbus_695',['usb_bus',['../structbladerf__devinfo.html#aed755de9311701fa83379132e69e53df',1,'bladerf_devinfo']]]
];
