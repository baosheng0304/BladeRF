var searchData=
[
  ['gain_20stages_20_28deprecated_29_609',['Gain stages (deprecated)',['../group___f_n___b_l_a_d_e_r_f1___g_a_i_n.html',1,'']]],
  ['gain_610',['Gain',['../group___f_n___g_a_i_n.html',1,'']]]
];
