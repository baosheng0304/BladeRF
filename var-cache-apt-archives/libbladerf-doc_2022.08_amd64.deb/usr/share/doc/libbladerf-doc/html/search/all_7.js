var searchData=
[
  ['handle_611',['handle',['../structbladerf__backendinfo.html#a81011b79683fab64ce3aff71114f8fdd',1,'bladerf_backendinfo']]],
  ['handle_5fcount_612',['handle_count',['../structbladerf__backendinfo.html#af6ca46ab620aba757116b618ffe11883',1,'bladerf_backendinfo']]]
];
