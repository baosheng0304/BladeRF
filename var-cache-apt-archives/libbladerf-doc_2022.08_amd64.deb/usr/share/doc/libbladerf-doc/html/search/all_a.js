var searchData=
[
  ['magic_630',['magic',['../structbladerf__image.html#a91f000c62f901f00281ae577cb054c67',1,'bladerf_image']]],
  ['major_631',['major',['../structbladerf__version.html#a600930655b7237315b72223c48327ea8',1,'bladerf_version']]],
  ['manufacturer_632',['manufacturer',['../structbladerf__devinfo.html#acc4554d02a09a200b647b137c73ef087',1,'bladerf_devinfo']]],
  ['max_633',['max',['../structbladerf__range.html#a26e6db9bcc64b584051ecc28171ed11f',1,'bladerf_range']]],
  ['min_634',['min',['../structbladerf__range.html#ad10edae0a852d72fb76afb1c77735045',1,'bladerf_range']]],
  ['minor_635',['minor',['../structbladerf__version.html#a9f280ce3ae5b6cd9346fd7a09ff29168',1,'bladerf_version']]],
  ['mode_636',['mode',['../structbladerf__gain__modes.html#a9bd2d44001d16e880ba7a6a6691a5b47',1,'bladerf_gain_modes::mode()'],['../structbladerf__loopback__modes.html#a0735f209df91af1c3c77a47217d8365f',1,'bladerf_loopback_modes::mode()']]],
  ['metadata_20structure_20and_20flags_637',['Metadata structure and flags',['../group___s_t_r_e_a_m_i_n_g___f_o_r_m_a_t___m_e_t_a_d_a_t_a.html',1,'']]]
];
