var searchData=
[
  ['sampling_20mux_667',['Sampling Mux',['../group___f_n___b_l_a_d_e_r_f1___s_a_m_p_l_i_n_g___m_u_x.html',1,'']]],
  ['sample_20rate_668',['Sample rate',['../group___f_n___s_a_m_p_l_i_n_g.html',1,'']]],
  ['scheduled_20tuning_669',['Scheduled Tuning',['../group___f_n___s_c_h_e_d_u_l_e_d___t_u_n_i_n_g.html',1,'']]],
  ['smb_20clock_20port_20control_670',['SMB clock port control',['../group___f_n___s_m_b___c_l_o_c_k.html',1,'']]],
  ['spi_20flash_671',['SPI Flash',['../group___f_n___s_p_i___f_l_a_s_h.html',1,'']]],
  ['synchronous_20api_672',['Synchronous API',['../group___f_n___s_t_r_e_a_m_i_n_g___s_y_n_c.html',1,'']]],
  ['scale_673',['scale',['../structbladerf__range.html#a1d28dec57cce925ad92342891bd71e7c',1,'bladerf_range']]],
  ['serial_674',['serial',['../structbladerf__devinfo.html#abe126c2e73d5e14a30c3648521a9aee0',1,'bladerf_devinfo::serial()'],['../structbladerf__serial.html#abe126c2e73d5e14a30c3648521a9aee0',1,'bladerf_serial::serial()'],['../structbladerf__image.html#aaa74f66cc1ee926c3c8e871411c8fa5f',1,'bladerf_image::serial()']]],
  ['signal_675',['signal',['../structbladerf__trigger.html#a2bea7884d40e7f7af4a9e2fa9ca39661',1,'bladerf_trigger']]],
  ['spdt_676',['spdt',['../structbladerf__quick__tune.html#a77be955e492f82e89eea9cc2d5696f85',1,'bladerf_quick_tune']]],
  ['status_677',['status',['../structbladerf__metadata.html#ade20423e91627f07e610924cb0081623',1,'bladerf_metadata']]],
  ['step_678',['step',['../structbladerf__range.html#aa8630add62fc7df3a4559bd728d7f9b8',1,'bladerf_range']]],
  ['streaming_679',['Streaming',['../group___s_t_r_e_a_m_i_n_g.html',1,'']]],
  ['synchronous_20interface_3a_20rx_20with_20metadata_680',['Synchronous Interface: RX with Metadata',['../sync_rx_meta.html',1,'']]],
  ['synchronous_20interface_3a_20scheduled_20tx_20bursts_681',['Synchronous Interface: Scheduled TX bursts',['../sync_tx_meta_bursts.html',1,'']]]
];
