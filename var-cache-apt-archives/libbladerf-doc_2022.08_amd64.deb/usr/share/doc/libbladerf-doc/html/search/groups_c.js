var searchData=
[
  ['sampling_20mux_1206',['Sampling Mux',['../group___f_n___b_l_a_d_e_r_f1___s_a_m_p_l_i_n_g___m_u_x.html',1,'']]],
  ['sample_20rate_1207',['Sample rate',['../group___f_n___s_a_m_p_l_i_n_g.html',1,'']]],
  ['scheduled_20tuning_1208',['Scheduled Tuning',['../group___f_n___s_c_h_e_d_u_l_e_d___t_u_n_i_n_g.html',1,'']]],
  ['smb_20clock_20port_20control_1209',['SMB clock port control',['../group___f_n___s_m_b___c_l_o_c_k.html',1,'']]],
  ['spi_20flash_1210',['SPI Flash',['../group___f_n___s_p_i___f_l_a_s_h.html',1,'']]],
  ['synchronous_20api_1211',['Synchronous API',['../group___f_n___s_t_r_e_a_m_i_n_g___s_y_n_c.html',1,'']]],
  ['streaming_1212',['Streaming',['../group___s_t_r_e_a_m_i_n_g.html',1,'']]]
];
