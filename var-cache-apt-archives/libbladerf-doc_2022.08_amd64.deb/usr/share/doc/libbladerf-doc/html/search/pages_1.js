var searchData=
[
  ['configuration_20file_1220',['Configuration File',['../configfile.html',1,'']]]
];
