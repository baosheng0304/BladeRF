var searchData=
[
  ['device_20configuration_1221',['Device Configuration',['../boilerplate.html',1,'']]],
  ['deprecated_20list_1222',['Deprecated List',['../deprecated.html',1,'']]]
];
