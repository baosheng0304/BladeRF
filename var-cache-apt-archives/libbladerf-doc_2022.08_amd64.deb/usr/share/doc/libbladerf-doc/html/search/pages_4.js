var searchData=
[
  ['frequency_20tuning_20_28bladerf1_29_1224',['Frequency tuning (bladeRF1)',['../tuning.html',1,'']]]
];
