var searchData=
[
  ['synchronous_20interface_3a_20rx_20with_20metadata_1226',['Synchronous Interface: RX with Metadata',['../sync_rx_meta.html',1,'']]],
  ['synchronous_20interface_3a_20scheduled_20tx_20bursts_1227',['Synchronous Interface: Scheduled TX bursts',['../sync_tx_meta_bursts.html',1,'']]]
];
