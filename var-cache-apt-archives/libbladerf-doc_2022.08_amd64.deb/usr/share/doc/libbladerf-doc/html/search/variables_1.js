var searchData=
[
  ['backend_912',['backend',['../structbladerf__devinfo.html#a8b9925b92ef8bcfd7ebe0c26c742c5d7',1,'bladerf_devinfo']]]
];
