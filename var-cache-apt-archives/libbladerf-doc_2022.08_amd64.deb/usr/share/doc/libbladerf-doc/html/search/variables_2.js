var searchData=
[
  ['channel_913',['channel',['../structbladerf__trigger.html#a3073ae11892c658961b9950ad153163e',1,'bladerf_trigger']]],
  ['checksum_914',['checksum',['../structbladerf__image.html#a46c22fe33486cccc7f1792463d0ee8da',1,'bladerf_image']]]
];
