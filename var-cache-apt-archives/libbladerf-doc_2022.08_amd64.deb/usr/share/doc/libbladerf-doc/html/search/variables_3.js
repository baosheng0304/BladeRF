var searchData=
[
  ['data_915',['data',['../structbladerf__image.html#abe222f6d3581e7920dcad5306cc906a8',1,'bladerf_image']]],
  ['dc_5fref_916',['dc_ref',['../structbladerf__lms__dc__cals.html#a31b02eef31b734662bee7219035a445e',1,'bladerf_lms_dc_cals']]],
  ['den_917',['den',['../structbladerf__rational__rate.html#a79f155fae61d1864a103bcaa3bc1ed19',1,'bladerf_rational_rate']]],
  ['describe_918',['describe',['../structbladerf__version.html#a6cb72c004e9c3001d82d2b445700d34f',1,'bladerf_version']]]
];
