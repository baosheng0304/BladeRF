var searchData=
[
  ['flags_919',['flags',['../structbladerf__quick__tune.html#aa2585d779da0ab21273a8d92de9a0ebe',1,'bladerf_quick_tune::flags()'],['../structbladerf__metadata.html#a773b39d480759f67926cb18ae2219281',1,'bladerf_metadata::flags()']]],
  ['freqsel_920',['freqsel',['../structbladerf__quick__tune.html#afc127ee0e37863bbd6433d44155b5154',1,'bladerf_quick_tune']]]
];
