var searchData=
[
  ['instance_923',['instance',['../structbladerf__devinfo.html#a020ad41f5104a1bd5bb455b2144e8885',1,'bladerf_devinfo']]],
  ['integer_924',['integer',['../structbladerf__rational__rate.html#a88f9f5e1216d6aaa43434facecd25bc4',1,'bladerf_rational_rate']]]
];
