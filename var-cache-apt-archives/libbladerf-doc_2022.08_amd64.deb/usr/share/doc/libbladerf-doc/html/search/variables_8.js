var searchData=
[
  ['magic_929',['magic',['../structbladerf__image.html#a91f000c62f901f00281ae577cb054c67',1,'bladerf_image']]],
  ['major_930',['major',['../structbladerf__version.html#a600930655b7237315b72223c48327ea8',1,'bladerf_version']]],
  ['manufacturer_931',['manufacturer',['../structbladerf__devinfo.html#acc4554d02a09a200b647b137c73ef087',1,'bladerf_devinfo']]],
  ['max_932',['max',['../structbladerf__range.html#a26e6db9bcc64b584051ecc28171ed11f',1,'bladerf_range']]],
  ['min_933',['min',['../structbladerf__range.html#ad10edae0a852d72fb76afb1c77735045',1,'bladerf_range']]],
  ['minor_934',['minor',['../structbladerf__version.html#a9f280ce3ae5b6cd9346fd7a09ff29168',1,'bladerf_version']]],
  ['mode_935',['mode',['../structbladerf__gain__modes.html#a9bd2d44001d16e880ba7a6a6691a5b47',1,'bladerf_gain_modes::mode()'],['../structbladerf__loopback__modes.html#a0735f209df91af1c3c77a47217d8365f',1,'bladerf_loopback_modes::mode()']]]
];
