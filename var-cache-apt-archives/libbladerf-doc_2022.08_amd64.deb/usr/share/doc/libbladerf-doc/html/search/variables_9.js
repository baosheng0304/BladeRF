var searchData=
[
  ['name_936',['name',['../structbladerf__gain__modes.html#a8f8f80d37794cde9472343e4487ba3eb',1,'bladerf_gain_modes::name()'],['../structbladerf__loopback__modes.html#a8f8f80d37794cde9472343e4487ba3eb',1,'bladerf_loopback_modes::name()']]],
  ['nfrac_937',['nfrac',['../structbladerf__quick__tune.html#a50080ebeec7c7154a1370ef1f7db7ddf',1,'bladerf_quick_tune']]],
  ['nint_938',['nint',['../structbladerf__quick__tune.html#ae93bfb4125f8017c88a70641c3b526b9',1,'bladerf_quick_tune']]],
  ['nios_5fprofile_939',['nios_profile',['../structbladerf__quick__tune.html#abe69e13a34df10a3ffc1298e2449a0ed',1,'bladerf_quick_tune']]],
  ['num_940',['num',['../structbladerf__rational__rate.html#a696f04a74a4e56ba4247bae9f9d12322',1,'bladerf_rational_rate']]]
];
