var searchData=
[
  ['options_941',['options',['../structbladerf__trigger.html#af8d5876360e173d9700af08e0715ffe3',1,'bladerf_trigger']]]
];
